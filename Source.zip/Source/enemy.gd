extends CharacterBody3D

var health = 30
var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")
func take_damage(amount):
	health -= amount
	print("Enemy hit! Health:", health)

	if health <= 0:
		die()
func _physics_process(delta):

	if not is_on_floor():
		velocity.y -= gravity * delta
func die():
	queue_free()
