extends CharacterBody3D

@export var speed = 6.0
@export var mouse_sensitivity = 0.002
@export var jump_velocity = 4.5
var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")
var ammo_in_mag = 8
var max_ammo = 8
@onready var ammo_label_text = $Visuals/Label
@onready var head = $Head
@onready var ray = $Head/RayCast3D
@onready var shoot_audio = $AudioStreamPlayer3D
@onready var reload_audio = $AudioStreamPlayer3D2
@onready var reload_audio2 = $AudioStreamPlayer3D3
@onready var muzzle_flash = $Head/Camera3D/gun/flash
func _ready():
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _input(event):
	if event.is_action_pressed("r"):
		ammo_label_text.text = "Reloading..."
		reload_audio.play()
		await get_tree().create_timer(0.56).timeout
		reload_audio2.play()
		ammo_in_mag = max_ammo
		ammo_label_text.text = "ammo : " + str(ammo_in_mag)
	if event.is_action_pressed("shoot"):
		shoot()
	if event is InputEventMouseMotion:
		rotate_y(-event.relative.x * mouse_sensitivity)
		head.rotate_x(-event.relative.y * mouse_sensitivity)
		head.rotation.x = clamp(head.rotation.x, deg_to_rad(-80), deg_to_rad(80))

func _physics_process(delta):

	if not is_on_floor():
		velocity.y -= gravity * delta

	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = jump_velocity

	var input_dir = Input.get_vector("a","d","w","s")
	var direction = (transform.basis * Vector3(input_dir.x,0,input_dir.y)).normalized()

	if direction:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x,0,speed)
		velocity.z = move_toward(velocity.z,0,speed)

	move_and_slide()
func shoot():
	if ammo_in_mag == 0:
		return false
	if ray.is_colliding():
		var target = ray.get_collider()
		if target.has_method("take_damage"):
			target.take_damage(10)
	muzzle_flash.visible = true
	ammo_in_mag -= 1
	ammo_label_text.text = "ammo : " + str(ammo_in_mag)
	shoot_audio.play()
	await get_tree().create_timer(0.1).timeout
	muzzle_flash.visible = false
